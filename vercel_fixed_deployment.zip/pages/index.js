import Head from 'next/head';
import { useState } from 'react';
import styles from '../styles/Home.module.css';

export default function Home() {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [trackingResult, setTrackingResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!trackingNumber) {
      setError('Vui lòng nhập mã vận đơn');
      return;
    }
    
    setLoading(true);
    setError('');
    setTrackingResult(null);
    
    try {
      // Identify carrier
      const carrierInfo = identifyCarrier(trackingNumber);
      
      // Mock tracking data
      const result = getMockTrackingData(trackingNumber, carrierInfo);
      
      setTrackingResult(result);
    } catch (error) {
      setError('Lỗi khi truy vấn thông tin vận chuyển: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  // Function to identify carrier from tracking number
  const identifyCarrier = (trackingNumber) => {
    const patterns = {
      chinaPost: /^[A-Z]{2}\d{9}CN$/,
      sfExpress: /^\d{12}$/,
      ztoExpress: /^(ZTO)?\d{12,13}$/,
      ytoExpress: /^(YT|YTO)?\d{10,13}$/,
      stoExpress: /^(STO)?\d{10,12}$/,
      yundaExpress: /^(YD)?\d{10,13}$/
    };

    if (patterns.chinaPost.test(trackingNumber)) {
      return {
        carrier_id: 'china_post',
        name: 'China Post / EMS China'
      };
    } else if (patterns.sfExpress.test(trackingNumber)) {
      return {
        carrier_id: 'sf_express',
        name: 'SF Express'
      };
    } else if (patterns.ztoExpress.test(trackingNumber)) {
      return {
        carrier_id: 'zto',
        name: 'ZTO Express'
      };
    } else if (patterns.ytoExpress.test(trackingNumber)) {
      return {
        carrier_id: 'yto',
        name: 'YTO Express'
      };
    } else if (patterns.yundaExpress.test(trackingNumber)) {
      return {
        carrier_id: 'yunda',
        name: 'Yunda Express'
      };
    } else {
      return {
        carrier_id: 'unknown',
        name: 'Unknown Carrier'
      };
    }
  };

  // Function to get mock tracking data
  const getMockTrackingData = (trackingNumber, carrierInfo) => {
    if (carrierInfo.carrier_id === 'unknown') {
      throw new Error('Không thể nhận diện mã vận đơn hoặc không tìm thấy thông tin vận chuyển');
    }

    return {
      tracking_number: trackingNumber,
      carrier: carrierInfo.name,
      status: 'in_transit',
      events: [
        {
          time: new Date().toISOString(),
          location: 'Guangzhou, China',
          description: 'Đã rời trung tâm phân loại'
        },
        {
          time: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
          location: 'Guangzhou, China',
          description: 'Đã đến trung tâm phân loại'
        },
        {
          time: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
          location: 'Shenzhen, China',
          description: 'Đã rời kho vận chuyển'
        },
        {
          time: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
          location: 'Shenzhen, China',
          description: 'Đã nhận hàng từ người gửi'
        }
      ]
    };
  };

  // Function to format date
  const formatDate = (dateString) => {
    if (!dateString) return 'Không xác định';
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    
    return date.toLocaleString('vi-VN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Function to get status text
  const getStatusText = (status) => {
    const statusMap = {
      'delivered': 'Đã giao hàng',
      'in_transit': 'Đang vận chuyển',
      'pending': 'Chờ xử lý',
      'exception': 'Có vấn đề',
      'expired': 'Hết hạn',
      'undelivered': 'Chưa giao hàng',
      'pickup': 'Sẵn sàng lấy hàng',
      'info_received': 'Đã nhận thông tin'
    };
    
    return statusMap[status] || status;
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>Theo dõi Vận chuyển Trung Quốc</title>
        <meta name="description" content="Theo dõi hành trình vận chuyển của các đơn vị vận chuyển Trung Quốc" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <nav className={styles.navbar}>
        <div className={styles.navbarContainer}>
          <a className={styles.navbarBrand} href="#">
            <i className="fas fa-shipping-fast me-2"></i>
            Theo dõi Vận chuyển Trung Quốc
          </a>
        </div>
      </nav>

      <main className={styles.main}>
        <div className={styles.row}>
          <div className={styles.col}>
            <div className={styles.card}>
              <div className={styles.cardHeader}>
                <i className="fas fa-search me-2"></i>
                Nhập mã vận đơn
              </div>
              <div className={styles.cardBody}>
                <form onSubmit={handleSubmit}>
                  <div className={styles.formGroup}>
                    <input
                      type="text"
                      className={styles.formControl}
                      placeholder="Nhập mã vận đơn của bạn"
                      value={trackingNumber}
                      onChange={(e) => setTrackingNumber(e.target.value)}
                      required
                    />
                    <div className={styles.formText}>Hệ thống sẽ tự động nhận diện đơn vị vận chuyển từ mã vận đơn.</div>
                  </div>
                  <button type="submit" className={styles.btnPrimary}>
                    <i className="fas fa-search me-2"></i>
                    Tra cứu
                  </button>
                </form>
                
                {loading && (
                  <div className={styles.loading}>
                    <div className={styles.spinner}></div>
                    <p>Đang tra cứu thông tin vận chuyển...</p>
                  </div>
                )}
                
                {error && (
                  <div className={styles.errorMessage}>
                    {error}
                  </div>
                )}
              </div>
            </div>

            {trackingResult && (
              <div className={styles.card}>
                <div className={styles.cardHeader}>
                  <i className="fas fa-truck me-2"></i>
                  Kết quả theo dõi
                </div>
                <div className={styles.cardBody}>
                  <div className={styles.carrierInfo}>
                    <div className={styles.carrierLogo}>
                      <i className="fas fa-shipping-fast"></i>
                    </div>
                    <div>
                      <div className={styles.carrierName}>{trackingResult.carrier}</div>
                      <div className={styles.trackingNumber}>{trackingResult.tracking_number}</div>
                    </div>
                  </div>
                  
                  <div className={styles.trackingStatus}>
                    <div className={styles.statusLabel}>Trạng thái hiện tại</div>
                    <div className={styles.statusValue}>{getStatusText(trackingResult.status)}</div>
                  </div>
                  
                  <h6 className={styles.timelineTitle}>Hành trình nội địa Trung Quốc</h6>
                  
                  <div className={styles.timeline}>
                    {trackingResult.events && trackingResult.events.length > 0 ? (
                      trackingResult.events.map((event, index) => (
                        <div key={index} className={`${styles.timelineItem} ${index === 0 ? styles.active : ''}`}>
                          <div className={styles.timelineDate}>{formatDate(event.time)}</div>
                          <div className={styles.timelineLocation}>{event.location || 'Không xác định'}</div>
                          <div className={styles.timelineDescription}>{event.description}</div>
                        </div>
                      ))
                    ) : (
                      <div className={styles.noEvents}>
                        Không có thông tin hành trình nội địa Trung Quốc.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className={styles.footer}>
        <div className={styles.footerContainer}>
          <p>© 2025 Theo dõi Vận chuyển Trung Quốc. Tất cả các quyền được bảo lưu.</p>
        </div>
      </footer>
    </div>
  );
}
